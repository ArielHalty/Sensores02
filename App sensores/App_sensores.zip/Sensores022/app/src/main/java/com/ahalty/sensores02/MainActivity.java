package com.ahalty.sensores02;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.icu.text.Edits;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView txtSensores;
    private TextView txtAl;       // Aceleración Lineal.
    private TextView txtGir;      // Giroscopio.


    private SensorManager sensorManager;
    private List<Sensor> sensores;

    private Sensor sensorAl, sensorGir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSensores = (TextView) findViewById(R.id.txt_sensores);
        txtAl = (TextView) findViewById(R.id.txt_proximidad);
        txtGir = (TextView) findViewById(R.id.txt_luz);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensores = sensorManager.getSensorList(Sensor.TYPE_ALL);

        int i=1;
        for(Iterator<Sensor> it = sensores.iterator(); it.hasNext(); i++) {
            Sensor sensor = it.next();
            txtSensores.append(String.format("%d: %s, %d, %s\n", i, sensor.getName(), sensor.getType(), sensor.getVendor() ));
        }

        sensorAl = (Sensor) sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        sensorManager.registerListener(this, sensorAl, SensorManager.SENSOR_DELAY_NORMAL);

        sensorGir = (Sensor) sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        sensorManager.registerListener(this, sensorGir, SensorManager.SENSOR_DELAY_NORMAL);

    }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
             switch (sensorEvent.sensor.getType()) {
                 case Sensor.TYPE_LINEAR_ACCELERATION:
                     txtAl.setText(String.format("%f", sensorEvent.values[0]));
                     break;
                 case Sensor.TYPE_GYROSCOPE:
                     txtGir.setText(String.format("%f", sensorEvent.values[0]));
                     break;
             }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }

    }
